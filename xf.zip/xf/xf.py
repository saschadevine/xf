#!/usr/bin/env/python3
# xtf.py: E(X)cel (F)iller
# Fills an Excel template with data based on user-defined configurations
# SLD 2024




# Import modules
import json, os, sys, shutil
from openpyxl import load_workbook

# Collect available list of JSON config files
# Filename prefixes for these represent available command line arguments for user to specify
available_config_clargs, available_config_files = [], []
for this_file in os.listdir("./configs"):
    if this_file[-4:].lower()=="json":
        available_config_clargs.append(this_file[:-5])
        available_config_files.append("./configs/"+this_file)

# Get command line argument
# Expect exactly one: quit if too few or too many
if len(sys.argv)==2: clarg = sys.argv[1]
else: quit("\nIncorrect number of command line arguments specified\nRun:\tpython3 xf.py help\n")

# If we've gotten this far, we have exactly one clarg
# Is clarg valid? If not, inform user and quit
if not (clarg in ["help"]+available_config_clargs): quit("\nInvalid command line argument specified\nRun:\tpython3 xf.py help\n")

# If we've gotten this far, clarg is valid
# Is clarg ```help```? If yes, display help message and quit
if clarg=="help":
    help_message =  "\nUsage:\t\t\tpython3 xf.py ARGUMENT"
    help_message += "\nValid ARGUMENTs:\thelp"
    for indiv_clarg in available_config_clargs: help_message+="\n\t\t\t"+indiv_clarg
    quit(help_message+"\n")

# If we've gotten this far, clarg is valid and refers to a JSON config file
# Ready to try parsing: begin by opening the relevant file
json_filename = available_config_files[available_config_clargs.index(clarg)]
json_input = open(json_filename)

# Check to see if config file is valid JSON
# If not, quit and inform user the config file is unloadable
try:
    configs = json.load(json_input)

except:
    quit("\n'"+json_filename+"' is either not valid JSON, or contains errors\n")

json_input.close()

# If we've gotten this far, we have loaded the configuration list
# Check to see if all required elements are defined: we need them all
# Begin by defining all elements we need to find (hard-coded by design)
configs_found=  {
                    "source_file"               :False,
                    "compounds_file"            :False,
                    "template_file"             :False,
                    "output_file"               :False,
                    "working_sheets"            :False,
                    "compounds_source_range"    :False,
                    "compounds_dest_range"      :False,
                    "data_source_range"         :False,
                    "data_dest_range"           :False
                }

# Update the find list to reflect whether or not the config file defines each element
for this_config in configs_found:
    for item in configs:
        if item == this_config: 
            configs_found[this_config]=True

# Check to see if any elements are missing
# If yes, quit and inform user which one is missing
for this_config in configs_found:
    if not configs_found[this_config]:
        quit("\n'"+this_config+"' required but missing from '"+json_filename+"'\n")

# If we've made it this far, all configs are defined
# Next, check to see if source, compound and template files exist
# If any are missing, quit and inform user which is missing
if not os.path.isfile(configs["source_file"]):
    quit("\nSource file '"+configs["source_file"]+"' does not exist\n")

if not os.path.isfile(configs["compounds_file"]):
    quit("\nCompound file '"+configs["compounds_file"]+"' does not exist\n")

if not os.path.isfile(configs["template_file"]):
    quit("\nTemplate file '"+configs["template_file"]+"' does not exist\n")

# If we've made it this far, we have verified all required files exist
# Next, pass through each for some safety checks
for this_file in [configs["source_file"], configs["compounds_file"], configs["template_file"]]:

    # Is this file a valid XLSX file? If yes, get list of sheet names
    try:
        wb = load_workbook(filename = this_file)
    
    # If not, quit and inform user there's something wrong with it
    except:
        quit("\n'"+this_file+"' is either not a valid XLSX file, or contains errors\n")

    # Next, check to see that all sheets we need to work on, exist
    this_file_sheetnames = wb.sheetnames
    wb.close()
    
    for indiv_sheet in configs["working_sheets"]:
        if indiv_sheet in this_file_sheetnames: pass

        # If not, quit and inform the user the sheet is missing
        else: quit("\nSheet '"+indiv_sheet+"' required but missing from '"+this_file+"'\n")

# If we've made it this far, we have verified all XLSX files exist and contain the necessary sheets
# Next, copy the template file to the output directory
shutil.copy(configs["template_file"], configs["output_file"])

# Pause here until we can detect that the copied template exists: we need to open it next
while not os.path.isfile(configs["output_file"]): pass

# Open the template file to work with
wb_template = load_workbook(filename = configs["output_file"])

# Ready to fill the template: start with compound labels
# Open the compound file to copy from
wb_compounds = load_workbook(filename = configs["compounds_file"])

# Pass through all sheets in the template
for indiv_sheet in configs["working_sheets"]:

    # Get source range (compounds file) and destination range (output file)
    # Both ranges should be of the same dimensions
    source_range = wb_compounds[indiv_sheet][configs["compounds_source_range"]]
    dest_range = wb_template[indiv_sheet][configs["compounds_dest_range"]]

    # Get list of all source coordinates
    source_coordinates = []
    for dummy_row in source_range:
        for dummy_cell in dummy_row:
            source_coordinates.append(dummy_cell.coordinate)
    
    # Get list of all destination coordinates
    dest_coordinates = []
    for dummy_row in dest_range:
        for dummy_cell in dummy_row:
            dest_coordinates.append(dummy_cell.coordinate)

    # Copy source to destination
    for i in range(0,len(source_coordinates)):
        wb_template[indiv_sheet][dest_coordinates[i]].value = wb_compounds[indiv_sheet][source_coordinates[i]].value

# Done copying compound labels: close compounds file
wb_compounds.close

# Next, open the input data file to copy from
wb_input = load_workbook(filename = configs["source_file"])

# Pass through all sheets in the template
for indiv_sheet in configs["working_sheets"]:

    # Get source range (compounds file) and destination range (output file)
    # Both ranges should be of the same dimensions
    source_range = wb_input[indiv_sheet][configs["data_source_range"]]
    dest_range = wb_template[indiv_sheet][configs["data_dest_range"]]

    # Get list of all source coordinates
    source_coordinates = []
    for dummy_row in source_range:
        for dummy_cell in dummy_row:
            source_coordinates.append(dummy_cell.coordinate)
    
    # Get list of all destination coordinates
    dest_coordinates = []
    for dummy_row in dest_range:
        for dummy_cell in dummy_row:
            dest_coordinates.append(dummy_cell.coordinate)

    # Copy source to destination
    for i in range(0,len(source_coordinates)):
        wb_template[indiv_sheet][dest_coordinates[i]].value = wb_input[indiv_sheet][source_coordinates[i]].value

# Done copying input data: close input data file
wb_input.close

# Save output
wb_template.save(configs["output_file"])
wb_template.close